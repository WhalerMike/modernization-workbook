# Help Desk / Cloud Services — Hybrid AD → Entra ID implementation kit

Vendor-neutral — only the platforms the agency already runs (Entra ID,
**ServiceNow**, SAM/SailPoint). **ServiceNow-first:** every request enters a
ServiceNow triage queue, is classified by required authority, and is routed to
the ServiceNow or SAM approval pipeline — executing automatically through the
**Microsoft Entra ID Spoke** where one exists, and falling to a manual Help Desk
task only for the gaps.

## Contents

| Path | What it is |
|---|---|
| `documents/Helpdesk-Flow.docx` | **Start here.** Intake → triage → routing: the recommendation, the Entra ID Spoke capability crosswalk, the email-to-pipeline mechanisms, and **blueprint diagrams**. Includes ServiceNow + Microsoft references. |
| `documents/Help-Desk-Administrative-Responsibilities-Guide.docx` | Operations reference — authority boundaries, the PAG / PIM eligible-not-active model, the SAM/ServiceNow/Entra three-platform workflow, per-task procedures (with diagrams). |
| `documents/Enterprise-Application-Access-Governance-and-Approval-Model.docx` | Governing policy — risk-tiered approval chains, RACI, application ownership, group-based access, the three approval workflows (with diagrams). |
| `documents/Governance-Structure-Brief.docx` | The four-layer governance/ownership design concept underneath both (with diagram). |
| `implementation-path.md` | The operating model + the Task Authority & Routing Matrix (with the `Execution` column) + the four implementation layers + run order. |
| `lib/HelpDeskEntra.psm1` | Shared module — the **routing matrix as data** (`$RequestRoutingTable`, incl. `Execution`), Connect helper, critical-permission risk list, logging. **Extend the matrix here.** |
| `scripts/Invoke-RequestTriage.ps1` | Email triage classifier — classifies by authority, routes to ServiceNow / SAM / escalation; forces all `@microsoft.com` mail through triage. |
| `scripts/Get-EnterpriseAppInventory.ps1` | Inventory + auto risk-tier + orphaned-app + critical-permission scan (read-only). |
| `scripts/New-HelpDeskPAG.ps1` | Stands up the role-assignable PAG + PIM-eligible technicians. |
| `scripts/Add-AppAccessGroup.ps1` | A2 Application Access: assign a group to an app role (naming + nested-group guards). The manual path for the one-time group→app-role binding. |
| `scripts/Repair-ImmutableId.ps1` | A3 ImmutableID hard-match repair (Graph-only; dual-approval). |
| `scripts/Export-AccessCertification.ps1` | Per-app access roster for owner certification. |

The four `documents/*.docx` are also browsable on the site:
<https://whalermike.github.io/uiao/customer-documents/operational-guides/helpdesk-entra-operations/>

## Quick start

```powershell
Install-Module Microsoft.Graph -Scope CurrentUser
# preview everything first — all state-changing scripts honor -WhatIf
.\scripts\Get-EnterpriseAppInventory.ps1
.\scripts\Invoke-RequestTriage.ps1 -MailboxUpn 'helpdesk@agency.gov' -WhatIf
```

Read **`documents/Helpdesk-Flow.docx`** first for the recommendation and the
ServiceNow mechanisms; `implementation-path.md` for the authority matrix and the
kit layers. Search the scripts for `# CONFIGURE:` for the values you must supply
(tenant id, shared mailbox, ServiceNow + SAM endpoints/auth).

> Reference implementation for review/adaptation — correct against current
> Microsoft Graph PowerShell and ServiceNow's documented capabilities, not
> validated against a live tenant. Dry-run with `-WhatIf` before removing guards.
> The Entra ID Spoke requires ServiceNow Integration Hub; without it, every
> "Spoke" execution becomes a manual Help Desk task and the flow shape is unchanged.
