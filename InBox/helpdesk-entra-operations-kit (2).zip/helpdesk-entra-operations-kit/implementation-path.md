# Hybrid AD → Entra ID — Help Desk / Cloud Services Implementation Path

**Audience:** Cloud Services Team, Identity Engineering, IT Leadership
**Scope:** The existing Hybrid Active Directory → Microsoft Entra ID environment
**Status:** Reference implementation for agency review and adaptation
**Companion code:** `scripts/` (Microsoft Graph PowerShell) · `lib/HelpDeskEntra.psm1`

> This document turns the three governance documents into an executable path.
> It contains **no product names beyond the platforms you already run** —
> Microsoft Entra ID, ServiceNow, and SAM (your SailPoint IGA). It is written
> to be handed to the agency as-is.

---

## 0. The operating model this is built to

The Cloud Services Team does not need to sit in the
approval loop for routine help desk work. So this implementation is built on
one rule:

> **The Cloud Services Team is a higher-level review if the Help Desk is unable
> to perform the task. Their role is then to ensure that, if that task is routine,
> a path is created for Help Desk service. Approval and responsibility sit with the
> requester's manager (or the relevant owner), scaled to the authority the task
> actually requires.**

Everything flows from that. Requests are never handled as ad-hoc email to the
team; they are **triaged into ServiceNow or SAM**, approved there by the right
manager/owner, and only then returned to the team as governed, executable work.

**Where this intentionally differs from the source documents:** the Help Desk
guide inserts *"Help Desk Supervisor approval"* on several routine tasks
(MFA reset, license, OneDrive provisioning). That gate is **removed** here and
replaced by the **requester's manager**, because a senior peer team approving
each other's routine work adds latency without adding control.

---

## 1. The Task Authority & Routing Matrix (the spine)

This single table decides, for any incoming request: how much authority it
needs, who approves it, which system it is triaged into, and what the team
does. It is encoded as **data** in `lib/HelpDeskEntra.psm1`
(`$RequestRoutingTable`) so the classifier and the human runbook can never
drift apart — and so the agency can extend it without code changes.

> **Intake is ServiceNow-first.** How an email becomes a triaged ServiceNow record
> and gets routed to the right pipeline — the Exchange redirect, the Inbound Email
> Action, the reroute Business Rule, and the Entra ID Spoke execution mapping — is
> the subject of the companion **`helpdesk-flow.md`**. ServiceNow is the single
> front door; this matrix is the decision logic it applies.

| Authority | Meaning | Approver (owns responsibility) | Triaged to | Team role |
|-----------|---------|--------------------------------|------------|-----------|
| **A0** | No approval — routine | none | **ServiceNow** (record) | Execute |
| **A1** | Manager sign-off | **Requester's manager** | **ServiceNow** | Execute after approval |
| **A2** | Access governance | Manager **+ Application Owner** | **SAM** → ServiceNow exec | Execute after approval |
| **A3** | High authority | **IGO / Identity Eng** | **SAM** escalate → exec | Triage/escalate or execute-after-dual-approval |
| **OOS** | Out of scope | Security Admin / Identity Eng | **Escalate out** | Does not execute |

### Task → authority → destination

`Execution` is the recommended default execution path (see the ServiceNow Entra ID
Spoke crosswalk in `helpdesk-flow.md` §A3): **Spoke** = ServiceNow Flow Designer
auto-executes via the Entra ID Spoke; **Manual** = SCTASK to Help Desk / Cloud
Services; **SAM** = SAM connector; **Escalate/OOS** = out of this team's hands.

| Incoming request | Authority | Approver | Triage to | Execution | Team role |
|---|---|---|---|---|---|
| Password reset — cloud-only user | A0 | none (SSPR / identity-proof) | ServiceNow | Spoke (Password mgmt; **Delegated work/school grant** — not app-only) | Execute |
| Password reset — hybrid / federated user | A0 | none (SSPR / identity-proof) | ServiceNow | Manual — on-prem AD / SSPR writeback (Spoke resets Entra-cloud-only users) | Execute |
| OneDrive client-side fix (cache, sign-out/in, KFM, reinstall) | A0 | none | ServiceNow | Manual (client) | Execute |
| UPN-change re-sign-in guidance | A0 | none | ServiceNow | Manual (guidance) | Inform |
| Sign-in / audit-log retrieval (triage) | A0 | none | ServiceNow | Spoke (Audit logs) | Execute |
| MFA / auth-method reset | A1 | Requester's manager | ServiceNow | Spoke (User authentication) | Execute after approval |
| License assignment / change | A1 | Requester's manager | ServiceNow | Spoke (License mgmt) | Execute after approval |
| User enable / update / assign manager | A1 | Requester's manager | ServiceNow | Spoke (User mgmt) | Execute after approval |
| OneDrive provisioning (needs license) | A1 | Requester's manager | ServiceNow | Manual (M365 admin) | Execute after approval |
| **Enterprise App group access (Application Access)** | **A2** | Manager **+ Application Owner** | **SAM** → ServiceNow | Spoke (Group mgmt); group→app binding Manual | Execute after SAM approval |
| Access-certification revocation | A2 | SAM certification (App Owner) | SAM → ServiceNow | Spoke (Group mgmt) | Execute |
| Group creation + owner add/remove | A2 | App Owner + Identity Eng | SAM → ServiceNow | Spoke (Group mgmt) | Execute after approval |
| User create / disable (joiner / leaver) | A2 | Manager + HR / Owner (SAM lifecycle) | SAM → ServiceNow | Spoke (User mgmt) | Execute after approval |
| Device enable / disable / delete | A2 / OOS | Manager + Device team | ServiceNow | Spoke (Device mgmt) / device team | Execute after approval |
| **Admin Consent request** | **A3** | **IGO only** (App Owner sponsors) | **SAM** → IGO; log in ServiceNow | Escalate-only | **Triage + escalate ONLY** |
| ImmutableID repair | A3 | Identity Eng Lead **+ IGO** | SAM dual-approval → ServiceNow | Manual (Graph script — gap) | Execute after dual approval |
| Conditional Access change | OOS | Security Admin + IGO | Escalate | Manual (Security) | Identify + escalate |
| Directory-role assignment | OOS | Identity Eng + IGO | Escalate | Manual (Identity Eng) | Out of scope |
| Service Principal / App Registration | OOS | App Owner + Identity Eng | Escalate | Manual (Identity Eng) | Out of scope |
| Organization (tenant) info | OOS/ref | Identity Eng | Escalate | Spoke (Org mgmt) reference | Out of scope |

**The triage rule, in one line:**
`A0/A1 → ServiceNow · A2/A3 → SAM (→ ServiceNow exec) · OOS → escalate out`.
**Execution rule:** prefer the **Entra ID Spoke** auto-action where one exists;
fall to a **Manual** SCTASK (Help Desk first; Cloud Services only when the Help Desk
can't) for the gaps (OneDrive, ImmutableID, Conditional Access, the one-time
group→app-role binding).

### Hard rule: Microsoft notification mail is never direct

Any message from **`@microsoft.com`** — especially
**`MSSecurity-noreply@microsoft.com`** — is force-classified as **A3,
triage-and-escalate only**. It is never actioned from the email and never
allowed to fall through to a lower-authority rule. Admin Consent is approved
by the IGO alone; the team's role is to verify in the audit log and escalate.

---

## 2. Implementation layers

### Layer 0 — Ownership & structure foundation *(the part AD used to provide)*

Every approval path above routes through a **manager** or an **owner**. That
mapping — *which user belongs to which department, and who owns which
application* — is exactly what Active Directory used to supply implicitly (OUs,
the `manager` attribute, group structure). As AD is retired, that topology has
to be sourced explicitly.

- **Today (interim):** derive the manager/department mapping from the current
  internal source — the `manager` and `department` attributes as they flow into
  Entra from the existing directory. SAM holds the authoritative owner ↔
  application mapping.
- **Future:** the same structure is fed from the authoritative HR system. The
  implementation treats the source as a **swappable seam** — the governance and
  execution layers above do not change when the source changes.

Keep this layer's name neutral (e.g. *"Access Authority Map"*). It is the
foundation the matrix sits on.

### Layer 1 — Inventory, ownership & risk *(prerequisite to everything)*

Run **`scripts/Get-EnterpriseAppInventory.ps1`**. It enumerates every
Enterprise Application and produces, per app: owner status, the application
permissions it holds, and an **auto-assigned risk tier**:

- **Orphaned apps (no owner) → auto-Tier 1.** An app with no accountable owner
  has no one to route its approvals through — fix these first.
- **Apps holding critical application permissions** (`*.All`, `Mail.Send`,
  `RoleManagement.ReadWrite.Directory`, …) **→ Tier 1.**

Output: `app-inventory.csv`. This is the catalog SAM and the matrix operate on.

### Layer 2 — Help Desk capability (the PAG)

Run **`scripts/New-HelpDeskPAG.ps1`**. There is **no native "Help Desk" Entra
role** that covers identity operations, so capability is delivered through a
**role-assignable Privileged Access Group**:

- Roles (**Application Administrator**, **Hybrid Identity Administrator**) are
  assigned to the **group**, never to individuals.
- The three technicians are **PIM-eligible members** — they hold nothing
  standing; they activate just-in-time.
- Activation policy (apply + verify in portal): **4-hour** max, **MFA on
  activation**, **approval required**, **justification required** (must carry
  the ServiceNow RITM number).

> Licensing: role-assignable groups require Entra ID **P1**; PIM activation
> requires **P2 / Entra ID Governance**.

### Layer 3 — Operations (the runbook, with code)

| Task | Script | Notes |
|---|---|---|
| Triage intake → route | `Invoke-RequestTriage.ps1` | Reads the shared mailbox; applies §1 matrix; opens ServiceNow/SAM items |
| Application Access (A2) | `Add-AppAccessGroup.ps1` | Requires `-ApprovalRef`; validates naming; **refuses nested groups** |
| ImmutableID repair (A3) | `Repair-ImmutableId.ps1` | Graph-only; **dual-approval** params required; `-WhatIf` aware |
| Quarterly certification | `Export-AccessCertification.ps1` | Per-app roster for owner certify/revoke |

---

## 3. Two platform realities the code enforces

1. **Entra does not honor nested groups for Enterprise App assignment.** A
   group assigned to an app grants access only to its **direct** user members.
   `Add-AppAccessGroup.ps1` detects nested groups and refuses to proceed; the
   certification export lists direct members only.
2. **Admin Consent is tenant-wide and permanent until revoked.** It is never a
   Cloud Services Team action — triage, verify in the audit log, escalate to the
   App Owner → IGO. The triage classifier hard-codes this.

---

## 4. Run order

```powershell
# One-time prerequisites
Install-Module Microsoft.Graph -Scope CurrentUser

# 1. Inventory + risk + orphans (read-only)
.\scripts\Get-EnterpriseAppInventory.ps1 -OutputPath .\app-inventory.csv

# 2. Assign owners to orphaned/critical apps in Entra + SAM (Layer 1 close-out)
#    (owner assignment is a governance decision — do it from the inventory)

# 3. Stand up the Help Desk PAG (preview first)
.\scripts\New-HelpDeskPAG.ps1 -TechnicianUpns 'a@agency.gov','b@agency.gov','c@agency.gov' -WhatIf

# 4. Turn on triage (preview first — shows routing decisions, touches nothing)
.\scripts\Invoke-RequestTriage.ps1 -MailboxUpn 'helpdesk@agency.gov' -WhatIf

# 5. Day-to-day operations
.\scripts\Add-AppAccessGroup.ps1 -AppDisplayName 'Payroll' -GroupName 'APP-PAYROLL-USERS-T1' -ApprovalRef 'RITM0045821' -WhatIf
.\scripts\Export-AccessCertification.ps1
```

Every state-changing script supports **`-WhatIf`**. Run it first.

---

## 5. What you must configure / what's deliberately left open

- **`# CONFIGURE:`** markers in the code: tenant id, the Help Desk shared
  mailbox, and the **ServiceNow** and **SAM** connector endpoints + auth. The
  connectors are scaffolded with the canonical REST shapes but are intentionally
  not wired to live systems.
- **The matrix is a starting point.** When the agency returns more accurate
  approval paths — or you discover task types not listed here — edit
  `$RequestRoutingTable` in `lib/HelpDeskEntra.psm1`. Add a row (keyword
  `Match`, `Authority`, `Destination`, `Approver`); nothing else changes.
- **Not tenant-tested.** This is a correct-by-construction reference against
  current Microsoft Graph PowerShell, not a package validated against your live
  tenant. Treat first runs as `-WhatIf` dry runs and confirm behavior before
  removing the guard.

---

## 6. Source-document cross-reference

| This guide | Source |
|---|---|
| §1 matrix, triage | Help Desk Guide §2, §5–§7; Governance Structure Brief §4 routing |
| Layer 1 risk tiers | Enterprise App Governance (Doc 3) §4, §8.3 |
| Layer 2 PAG / PIM | Help Desk Guide §3–§4 |
| Layer 3 App Access | Help Desk Guide §8; nested groups §7.4 |
| ImmutableID repair | Help Desk Guide §9 |
| Certification | Doc 3 §10.3; Governance Structure Brief §6.3 / §8.4 |

A copy of Doc 3 with its ownership-hierarchy terminology normalized ships
alongside this guide as
`IDG-GOV-003-Enterprise-App-Access-Governance-SCRUBBED.{md,docx}`.
