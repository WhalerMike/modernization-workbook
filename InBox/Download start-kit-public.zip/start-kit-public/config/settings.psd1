@{
 Version='Public-1.0'
 Domains=@('corp.example.com','eu.example.com')
 StaleDays=90
}
