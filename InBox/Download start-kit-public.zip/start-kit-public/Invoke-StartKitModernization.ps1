Write-Host 'Public workflow entry point.'
