Publicization rules:
- Use example.com domains.
- Use synthetic accounts.
- Do not include real findings.
- Remove customer infrastructure identifiers.
