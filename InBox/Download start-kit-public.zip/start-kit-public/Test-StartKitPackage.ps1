Get-ChildItem $PSScriptRoot -Recurse -Filter *.ps1 | Select-Object Name
